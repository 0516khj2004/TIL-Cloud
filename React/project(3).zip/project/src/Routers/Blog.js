import React from 'react';


import Add from '../Containers/Blog/component/Add'
import Users from '../Containers/Blog/component/users'
const Blog = () => {
    return (
        <div>
           <Add />
           <Users />
        </div>
    );
};

export default Blog;