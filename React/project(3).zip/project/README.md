## npm install --save list

```
npm install --save axios react-sparklines react react-router-dom react-redux redux youtube-api-search 
```

